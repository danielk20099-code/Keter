(() => {
  const root = document.querySelector("[data-product-root]"),
    form = document.querySelector(".native-product-form"),
    data = document.querySelector("[data-product-json]");
  if (!root || !form || !data) return;
  const product = JSON.parse(data.textContent),
    price = root.querySelector("[data-product-price]"),
    id = form.querySelector("[data-variant-id]"),
    add = form.querySelector("[data-add-product]"),
    error = form.querySelector("[data-product-error]");
  function showMedia(mediaId) {
    document.querySelectorAll("[data-product-media]").forEach((media) => {
      const active = media.dataset.productMedia === String(mediaId);
      media.hidden = !active;
      if (!active)
        media.querySelectorAll("video").forEach((video) => video.pause());
    });
    root
      .querySelectorAll("[data-show-media]")
      .forEach((button) =>
        button.setAttribute(
          "aria-pressed",
          String(button.dataset.showMedia === String(mediaId)),
        ),
      );
  }
  function variantChange(clearError = true) {
    const values = [...form.querySelectorAll("[data-option-index]")].map(
      (group) => group.querySelector("input:checked")?.value,
    );
    const variant = product.variants.find(
      (v) =>
        !values.length || v.options.every((value, i) => value === values[i]),
    );
    id.value = variant?.id || "";
    add.disabled = !variant?.available;
    add.querySelector("span").textContent = variant?.available
      ? "Add to bag"
      : variant
        ? "Sold out"
        : "Unavailable";
    if (variant) {
      price.textContent = window.Keter.money(variant.price);
      const url = new URL(window.location.href);
      url.searchParams.set("variant", variant.id);
      history.replaceState(null, "", url);
      if (variant.featured_media?.id) showMedia(variant.featured_media.id);
    }
    if (clearError) error.hidden = true;
  }
  form.addEventListener("change", variantChange);
  root.querySelectorAll("[data-quantity-step]").forEach((button) =>
    button.addEventListener("click", () => {
      const input = form.querySelector("[name=quantity]");
      input.value = String(
        Math.max(
          1,
          Math.min(
            99,
            Number(input.value) + Number(button.dataset.quantityStep),
          ),
        ),
      );
    }),
  );
  root
    .querySelectorAll("[data-show-media]")
    .forEach((button) =>
      button.addEventListener("click", () =>
        showMedia(button.dataset.showMedia),
      ),
    );
  root.querySelector("[data-zoom]")?.addEventListener("click", () => {
    const media =
      root.querySelector("[data-product-media]:not([hidden])") ||
      root.querySelector(".native-product-media .garment");
    if (!media) return;
    document
      .querySelector("[data-zoom-content]")
      .replaceChildren(media.cloneNode(true));
    const dialog = document.getElementById("keter-zoom");
    dialog.showModal();
    document.body.style.overflow = "hidden";
  });
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!id.value || add.disabled) return;
    const quantity = Number(form.querySelector("[name=quantity]").value);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 99) {
      error.textContent = "Please choose a quantity between 1 and 99.";
      error.hidden = false;
      return;
    }
    add.disabled = true;
    const label = add.querySelector("span");
    label.textContent = "Adding…";
    try {
      await window.KeterCart.add(Number(id.value), quantity);
      error.hidden = true;
    } catch (failure) {
      error.textContent = failure.message;
      error.hidden = false;
    } finally {
      variantChange(false);
    }
  });
})();
