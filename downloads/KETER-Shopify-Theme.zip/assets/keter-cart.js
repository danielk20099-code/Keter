(() => {
  const { route, money } = window.Keter;
  let busy = false;
  const escape = (value) =>
    String(value ?? "").replace(
      /[&<>"']/g,
      (char) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[char],
    );
  const request = async (path, body) => {
    const response = await fetch(route(path), {
      method: body ? "POST" : "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await response.json();
    if (!response.ok)
      throw new Error(
        data.description || data.message || "Unable to update your bag.",
      );
    return data;
  };
  async function refresh() {
    const target = document.querySelector("[data-drawer-cart]");
    if (!target) return;
    try {
      const cart = await request("cart.js");
      document
        .querySelectorAll(".bag-count,[data-cart-count]")
        .forEach((n) => (n.textContent = String(cart.item_count)));
      target.innerHTML = cart.items.length
        ? `<div class="cart-lines">${cart.items.map((item) => `<article class="cart-line"><a class="cart-image" href="${escape(item.url)}">${item.featured_image?.url ? `<img src="${escape(item.featured_image.url)}" alt="${escape(item.featured_image.alt || item.product_title)}" loading="lazy" width="100" height="125">` : ""}</a><div><a href="${escape(item.url)}">${escape(item.product_title)}</a><p>${escape(item.variant_title || "")}</p><div class="quantity"><button data-cart-key="${escape(item.key)}" data-cart-quantity="${item.quantity - 1}" aria-label="Decrease ${escape(item.product_title)} quantity">−</button><span>${item.quantity}</span><button data-cart-key="${escape(item.key)}" data-cart-quantity="${item.quantity + 1}" aria-label="Increase ${escape(item.product_title)} quantity">＋</button></div><button class="text-link small" data-cart-key="${escape(item.key)}" data-cart-quantity="0">Remove</button></div><span>${money(item.final_line_price)}</span></article>`).join("")}</div><div class="cart-total"><span>Subtotal</span><span>${money(cart.total_price)}</span></div><p class="muted small">Shipping and taxes calculated at checkout.</p><form method="post" action="${route("cart")}"><button class="button full" name="checkout" type="submit">Checkout <span aria-hidden="true">→</span></button></form>`
        : `<div class="empty-bag"><p class="display">Room for something<br><i>considered.</i></p><p>Your bag is currently empty.</p><a class="button" href="${route("collections/all")}">Explore the collection</a></div>`;
    } catch (error) {
      target.replaceChildren();
      const p = document.createElement("p");
      p.className = "field-error";
      p.setAttribute("role", "alert");
      p.textContent = error.message;
      target.append(p);
    }
  }
  document.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-cart-key]");
    if (!button || busy) return;
    busy = true;
    const target = document.querySelector("[data-drawer-cart]");
    target.querySelectorAll("button").forEach((b) => (b.disabled = true));
    try {
      await request("cart/change.js", {
        id: button.dataset.cartKey,
        quantity: Math.min(99, Number(button.dataset.cartQuantity)),
      });
      await refresh();
    } catch (error) {
      const p = document.createElement("p");
      p.className = "field-error";
      p.setAttribute("role", "alert");
      p.textContent = error.message;
      target.append(p);
      target.querySelectorAll("button").forEach((b) => (b.disabled = false));
    } finally {
      busy = false;
    }
  });
  window.KeterCart = {
    refresh,
    async add(id, quantity) {
      await request("cart/add.js", { items: [{ id, quantity }] });
      await refresh();
      const dialog = document.getElementById("keter-cart");
      if (!dialog.open) {
        dialog.showModal();
        document.body.style.overflow = "hidden";
      }
    },
  };
})();
