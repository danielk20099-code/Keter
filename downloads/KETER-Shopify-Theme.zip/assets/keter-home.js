(async () => {
  const pendingButtons = [
    ...document.querySelectorAll("[data-concept-explorer] button"),
  ];
  pendingButtons.forEach((button) => (button.disabled = true));
  let concepts = [];
  try {
    const response = await fetch(window.Keter.concepts);
    if (!response.ok) throw new Error("Concept media unavailable");
    concepts = await response.json();
  } catch {
    pendingButtons.forEach((button) => (button.disabled = false));
    return;
  }
  const reduced = window.Keter.reducedMotion;
  const svgFor = (product, slim = false) =>
    product?.[slim ? "slimSvg" : "svg"] || product?.svg;
  function animateShape(svg, path) {
    const paths = svg?.querySelectorAll(":scope > path");
    if (!paths) return;
    paths.forEach((node) => {
      const before = node.getAttribute("d"),
        from = before.match(/-?\d*\.?\d+/g)?.map(Number),
        to = path.match(/-?\d*\.?\d+/g)?.map(Number);
      if (reduced.matches || !from || !to || from.length !== to.length) {
        node.setAttribute("d", path);
        return;
      }
      const start = performance.now();
      const update = (now) => {
        const progress = Math.min(1, (now - start) / 550),
          eased = 1 - Math.pow(1 - progress, 3);
        let index = 0;
        node.setAttribute(
          "d",
          path.replace(/-?\d*\.?\d+/g, () =>
            String(from[index] + (to[index] - from[index++]) * eased),
          ),
        );
        if (progress < 1) requestAnimationFrame(update);
      };
      requestAnimationFrame(update);
    });
  }
  document
    .querySelectorAll("[data-fit-lab],.fit-section")
    .forEach((section) => {
      section.querySelectorAll(".fit-toggle button").forEach((button) =>
        button.addEventListener("click", () => {
          const slim = button.textContent.trim() === "Slim Athletic";
          section.querySelectorAll(".fit-toggle button").forEach((b) => {
            b.classList.toggle("selected", b === button);
            b.setAttribute("aria-pressed", String(b === button));
          });
          const source = new DOMParser().parseFromString(
            svgFor(concepts[0], slim),
            "image/svg+xml",
          );
          const nextPath = source
            .querySelector("svg > path")
            ?.getAttribute("d");
          if (nextPath)
            animateShape(section.querySelector(".fit-stage svg"), nextPath);
          section.querySelector(".fit-description").textContent = slim
            ? "A close, athletic line. Defined shoulders and a considered taper through the body."
            : "More space. Dropped shoulders. An easy, architectural shape that moves with you.";
          section.querySelector(".fit-label").textContent = slim
            ? "02 / THE SLIM ATHLETIC FIT"
            : "01 / THE OVERSIZED FIT";
          const label = section.querySelector(".measurement-line span");
          if (label)
            label.textContent = slim ? "DEFINED SHOULDER" : "RELAXED SHOULDER";
        }),
      );
    });
  const explorer = document.querySelector("[data-concept-explorer]");
  if (explorer) {
    let index = 0;
    const stage = explorer.querySelector(
        ".explorer-stage > div:not(.stage-arrows)",
      ),
      panel = explorer.querySelector(".explorer-product"),
      tabs = [...explorer.querySelectorAll("[role=tab]")];
    const setColor = (color, button) => {
      stage.querySelector("svg > path")?.setAttribute("fill", color.hex);
      panel.querySelectorAll(".swatches button").forEach((b) => {
        b.classList.toggle("selected", b === button);
        b.setAttribute("aria-pressed", String(b === button));
      });
      panel.querySelector(".small").textContent =
        `${color.name} / ${concepts[index].fits[0]}`;
    };
    const render = (next) => {
      index = (next + concepts.length) % concepts.length;
      const product = concepts[index];
      stage.innerHTML = svgFor(product);
      if (!reduced.matches)
        stage.animate(
          [
            { opacity: 0, transform: "translateY(14px)" },
            { opacity: 1, transform: "translateY(0)" },
          ],
          { duration: 650, easing: "cubic-bezier(.22,1,.36,1)" },
        );
      tabs.forEach((tab, i) => {
        tab.setAttribute("aria-selected", String(i === index));
        tab.tabIndex = i === index ? 0 : -1;
      });
      panel.setAttribute("aria-labelledby", `concept-tab-${index}`);
      panel.querySelector("h3").textContent = product.name;
      panel.querySelector(".eyebrow").textContent =
        `${product.category} / CONCEPT COLLECTION`;
      panel.querySelector("h3 + p").textContent = product.description;
      panel.querySelectorAll("dd")[0].textContent = product.fabric;
      panel.querySelectorAll("dd")[1].textContent = new Intl.NumberFormat(
        "en-US",
        { style: "currency", currency: "USD", maximumFractionDigits: 0 },
      ).format(product.price);
      const swatches = panel.querySelector(".swatches");
      swatches.replaceChildren();
      product.colors.forEach((color, i) => {
        const button = document.createElement("button");
        button.style.backgroundColor = color.hex;
        button.setAttribute("aria-label", `Select ${color.name}`);
        button.addEventListener("click", () => setColor(color, button));
        swatches.append(button);
        if (i === 0) setColor(color, button);
      });
      explorer.querySelector(".stage-bottom").textContent =
        `CONCEPT ${String(index + 1).padStart(2, "0")} / ${String(concepts.length).padStart(2, "0")}`;
    };
    tabs.forEach((tab, i) => {
      tab.addEventListener("click", () => render(i));
      tab.addEventListener("keydown", (event) => {
        let next;
        if (["ArrowRight", "ArrowDown"].includes(event.key)) next = i + 1;
        else if (["ArrowLeft", "ArrowUp"].includes(event.key)) next = i - 1;
        else if (event.key === "Home") next = 0;
        else if (event.key === "End") next = tabs.length - 1;
        if (next !== undefined) {
          event.preventDefault();
          render(next);
          tabs[index].focus();
        }
      });
    });
    const arrows = explorer.querySelectorAll(".stage-arrows button");
    arrows[0]?.addEventListener("click", () => render(index - 1));
    arrows[1]?.addEventListener("click", () => render(index + 1));
    render(0);
    pendingButtons.forEach((button) => (button.disabled = false));
  }
  const points = [
    [
      "Corner 01",
      "One of four defined corners, integrated into the shape of the garment.",
    ],
    ["Corner 02", "The front corner is shaped to sit naturally with the hem."],
    [
      "Corner 03",
      "The opposite corner mirrors the construction for a considered balance.",
    ],
    [
      "Corner 04",
      "The fourth corner completes the garment’s four-corner construction.",
    ],
    [
      "Side opening",
      "An intentional side opening creates separation while keeping the silhouette clean.",
    ],
    [
      "Reinforced opening",
      "A reinforced attachment point is designed with daily wear and finishing in mind.",
    ],
    [
      "Tzitzit finishing",
      "Tzitzit are tied during a dedicated finishing stage, before final quality control.",
    ],
  ];
  const flow = [
    "We start with fabric, pattern, silhouette, and the integrated four-corner form.",
    "Artwork and considered finishing become part of the garment’s identity.",
    "A dedicated tying stage brings the threads into the finished construction.",
    "Every garment moves through a final check for consistency and finishing.",
    "The final piece is prepared for its next chapter: your everyday wardrobe.",
  ];
  document
    .querySelectorAll("[data-construction],.construction-section")
    .forEach((section) => {
      section.querySelectorAll(".garment-point").forEach((button, i) =>
        button.addEventListener("click", () => {
          section.querySelectorAll(".garment-point").forEach((b) => {
            b.classList.toggle("selected", b === button);
            b.setAttribute("aria-pressed", String(b === button));
          });
          section.querySelector(".construction-detail h3").textContent =
            points[i][0];
          section.querySelector(".construction-detail p").textContent =
            points[i][1];
          section.querySelector(".construction-detail .eyebrow").textContent =
            `0${i + 1} / THE DETAIL`;
        }),
      );
      section
        .querySelector(".layer-control")
        ?.addEventListener("click", (event) => {
          const button = event.currentTarget,
            open = button.getAttribute("aria-pressed") === "true";
          button.setAttribute("aria-pressed", String(!open));
          section.classList.toggle("layers-separated", !open);
          button.firstChild.textContent = open
            ? "Separate construction layers "
            : "Reassemble garment ";
        });
      section.querySelectorAll(".production-flow button").forEach((button, i) =>
        button.addEventListener("click", () => {
          section
            .querySelectorAll(".production-flow button")
            .forEach((b) => b.classList.toggle("selected", b === button));
          section.querySelector(".production-caption").textContent = flow[i];
        }),
      );
    });
  const descriptions = [
    "A substantial, structured cotton. Made for a better everyday silhouette.",
    "Smooth stretch fabric, selected for comfort and freedom of movement.",
    "A dimensional double knit. Smooth on the inside. Clean on the outside. No fleece.",
  ];
  document
    .querySelectorAll("[data-material-lab],.material-section")
    .forEach((section) => {
      section.querySelectorAll(".material-card").forEach((button, i) => {
        button.addEventListener("click", () => {
          section.querySelectorAll(".material-card").forEach((b) => {
            b.classList.toggle("selected", b === button);
            b.setAttribute("aria-pressed", String(b === button));
            b.querySelector(".material-info > span").textContent =
              b === button ? "−" : "+";
          });
          section.querySelector(".material-description .eyebrow").textContent =
            button.querySelector("h3").innerText.replace(/\n/g, " ");
          section.querySelector(".material-description p").textContent =
            descriptions[i];
        });
        const texture = button.querySelector(".fabric-texture");
        button.addEventListener("pointermove", (event) => {
          if (reduced.matches || event.pointerType === "touch") return;
          const rect = button.getBoundingClientRect();
          texture.style.transform = `perspective(1000px) rotateY(${((event.clientX - rect.left) / rect.width - 0.5) * 5}deg) rotateX(${(0.5 - (event.clientY - rect.top) / rect.height) * 5}deg)`;
        });
        button.addEventListener(
          "pointerleave",
          () => (texture.style.transform = ""),
        );
      });
    });
  const units = document.querySelectorAll(
    ".size-guide-toolbar .fit-toggle button",
  );
  units.forEach((button) =>
    button.addEventListener("click", () => {
      const inches = button.textContent.trim() === "IN";
      units.forEach((b) => {
        b.classList.toggle("selected", b === button);
        b.setAttribute("aria-pressed", String(b === button));
      });
      document.querySelectorAll(".table-scroll tbody td").forEach((cell) => {
        cell.dataset.cm ||= cell.textContent.trim();
        cell.textContent = inches
          ? (Number(cell.dataset.cm) / 2.54).toFixed(1)
          : cell.dataset.cm;
      });
      document
        .querySelectorAll(".table-scroll thead th")
        .forEach(
          (cell) =>
            (cell.textContent = cell.textContent.replace(
              /\((?:cm|in)\)/,
              inches ? "(in)" : "(cm)",
            )),
        );
    }),
  );
})();
