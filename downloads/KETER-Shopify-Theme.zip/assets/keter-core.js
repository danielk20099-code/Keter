(() => {
  const route = (path) =>
    `${window.Keter.root.replace(/\/$/, "")}/${path.replace(/^\//, "")}`;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const money = (cents) =>
    new Intl.NumberFormat(document.documentElement.lang || "en", {
      style: "currency",
      currency: window.Keter.currency || "USD",
    }).format(cents / 100);
  window.Keter = { ...window.Keter, route, money, reducedMotion };
  document.addEventListener("click", (event) => {
    const opener = event.target.closest("[data-open-menu],[data-open-cart]");
    if (opener) {
      const id = opener.hasAttribute("data-open-menu")
        ? "keter-menu"
        : "keter-cart";
      const dialog = document.getElementById(id);
      if (dialog && !dialog.open) {
        dialog.showModal();
        document.body.style.overflow = "hidden";
      }
      if (id === "keter-cart") window.KeterCart?.refresh();
    }
    const close = event.target.closest("[data-close-dialog]");
    if (close) close.closest("dialog")?.close();
    if (event.target instanceof HTMLDialogElement) {
      const rect = event.target.getBoundingClientRect();
      if (
        event.clientX < rect.left ||
        event.clientX > rect.right ||
        event.clientY < rect.top ||
        event.clientY > rect.bottom
      )
        event.target.close();
    }
  });
  document.querySelectorAll("dialog").forEach((dialog) =>
    dialog.addEventListener("close", () => {
      if (!document.querySelector("dialog[open]"))
        document.body.style.overflow = "";
    }),
  );
  document.querySelectorAll(".faq-list h2 button").forEach((button) =>
    button.addEventListener("click", () => {
      const target = document.getElementById(
        button.getAttribute("aria-controls"),
      );
      if (!target) return;
      const open = button.getAttribute("aria-expanded") === "true";
      button.setAttribute("aria-expanded", String(!open));
      target.hidden = open;
    }),
  );
  const observer = new IntersectionObserver(
    (entries) =>
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      }),
    { threshold: 0.08 },
  );
  document
    .querySelectorAll(".story-title,.story-copy,.look")
    .forEach((node) => {
      if (!reducedMotion.matches) {
        node.classList.add("native-reveal");
        observer.observe(node);
      }
    });
})();
